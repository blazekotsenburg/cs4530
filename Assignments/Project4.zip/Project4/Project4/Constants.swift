//
//  Constants.swift
//  Project3
//
//  Created by Blaze Kotsenburg on 2/28/19.
//  Copyright © 2019 Blaze Kotsenburg. All rights reserved.
//

import Foundation

enum Constants {
    static let gameListFile = "battleshipListFile.json"
}
